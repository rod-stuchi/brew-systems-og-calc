# Beer OG Calculator — icon pack

Refractometer eyepiece view: blue above the reading line, white below, scale ticks that flip colour across the line.

Colours: navy #0d1b2a (also theme_color), blue #1d63c4 → #3f93f2, white #f5f9fd, scale blue #1a56ad.

## Files

| File | Use |
|---|---|
| favicon.ico | Legacy favicon (16, 32, 48) |
| favicon.svg | Modern favicon, simplified scale for tiny sizes |
| favicon-16/32/48.png | PNG favicons |
| apple-touch-icon.png | iOS home screen (180, opaque; iOS rounds the corners) |
| icon-192.png, icon-512.png | PWA icons, purpose "any" (rounded tile) |
| icon-maskable-192/512.png | PWA icons, purpose "maskable" (full bleed, content in safe zone) |
| icon.svg | Master app icon, vector |
| icon-maskable.svg, apple-touch-icon.svg | Vector sources for those PNGs |
| logo.svg, logo-1024.png | Round logo for headers, splash, docs |
| icon-mono.svg | One-colour silhouette (Safari pinned tab, print, embossing) |
| manifest.webmanifest | Ready-made manifest, icons expected under /icons/ |

## HTML head

```html
<link rel="icon" href="/icons/favicon.ico" sizes="48x48">
<link rel="icon" href="/icons/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
<link rel="mask-icon" href="/icons/icon-mono.svg" color="#0d1b2a">
<link rel="manifest" href="/manifest.webmanifest">
<meta name="theme-color" content="#0d1b2a">
```

Regenerate with `python3 build.py` (needs Playwright + Chromium and Pillow).
