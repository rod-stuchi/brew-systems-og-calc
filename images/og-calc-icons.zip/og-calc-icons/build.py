"""Build the Beer OG Calculator icon pack (refractometer eyepiece view)."""
import io, json, math, os, zipfile
from PIL import Image
from playwright.sync_api import sync_playwright

OUT = os.path.join(os.path.dirname(__file__), "og-calc-icons")
os.makedirs(OUT, exist_ok=True)

NAVY = "#0d1b2a"      # eyepiece / body
RING = "#24384f"      # lens barrel ring
BLUE_TOP = "#1d63c4"
BLUE_LOW = "#3f93f2"
WHITE = "#f5f9fd"
TICK_ON_BLUE = "#ffffff"
TICK_ON_WHITE = "#1a56ad"


def field(cx, cy, r, ring_w, boundary, spine_x, y0, y1, step, minor, major,
          w_minor, w_major, w_spine, uid, every=5, ticks=None):
    """The round eyepiece field: blue above the boundary, white below, scale on top."""
    if ticks is None:
        n = int(round((y1 - y0) / step))
        ticks = [(y0 + i * step, i % every == 0) for i in range(n + 1)]

    def scale(color):
        s = f'<line x1="{spine_x}" y1="{y0 - w_major/2}" x2="{spine_x}" y2="{y1 + w_major/2}" stroke="{color}" stroke-width="{w_spine}"/>'
        for y, is_major in ticks:
            L = major if is_major else minor
            w = w_major if is_major else w_minor
            s += f'<line x1="{spine_x}" y1="{y}" x2="{spine_x + L}" y2="{y}" stroke="{color}" stroke-width="{w}"/>'
        return s

    return f'''
  <defs>
    <clipPath id="f{uid}"><circle cx="{cx}" cy="{cy}" r="{r}"/></clipPath>
    <clipPath id="t{uid}"><rect x="0" y="0" width="1000" height="{boundary}"/></clipPath>
    <clipPath id="b{uid}"><rect x="0" y="{boundary}" width="1000" height="1000"/></clipPath>
    <linearGradient id="g{uid}" x1="0" y1="{cy - r}" x2="0" y2="{boundary}" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="{BLUE_TOP}"/><stop offset="1" stop-color="{BLUE_LOW}"/>
    </linearGradient>
  </defs>
  <g clip-path="url(#f{uid})">
    <rect x="0" y="0" width="1000" height="{boundary}" fill="url(#g{uid})"/>
    <rect x="0" y="{boundary}" width="1000" height="1000" fill="{WHITE}"/>
    <g clip-path="url(#t{uid})" stroke-linecap="butt">{scale(TICK_ON_BLUE)}</g>
    <g clip-path="url(#b{uid})" stroke-linecap="butt">{scale(TICK_ON_WHITE)}</g>
  </g>
  {f'<circle cx="{cx}" cy="{cy}" r="{r + ring_w/2}" fill="none" stroke="{RING}" stroke-width="{ring_w}"/>' if ring_w else ''}'''


def svg(body, size=512, bg=None):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">'
            f'{bg or ""}{body}\n</svg>\n')


def detailed(cx, cy, r, ring_w, uid):
    """Full scale; geometry expressed relative to the field radius."""
    k = r / 196
    return field(cx, cy, r, ring_w * k,
                 boundary=cy + 18 * k, spine_x=cx - 38 * k,
                 y0=cy - 142 * k, y1=cy + 146 * k, step=18 * k,
                 minor=34 * k, major=72 * k, w_minor=5 * k, w_major=8 * k, w_spine=8 * k, uid=uid)


def simple(cx, cy, r, ring_w, uid):
    """Few heavy marks, legible at 16-48 px."""
    k = r / 196
    ticks = [(cy - 120 * k, True), (cy - 60 * k, False), (cy, True), (cy + 60 * k, False), (cy + 120 * k, True)]
    return field(cx, cy, r, ring_w * k,
                 boundary=cy + 30 * k, spine_x=cx - 56 * k,
                 y0=cy - 120 * k, y1=cy + 120 * k, step=60 * k,
                 minor=60 * k, major=118 * k, w_minor=22 * k, w_major=26 * k, w_spine=26 * k, uid=uid,
                 ticks=ticks)


rounded_bg = lambda s, rx: f'<rect width="{s}" height="{s}" rx="{rx}" fill="{NAVY}"/>'
square_bg = lambda s: f'<rect width="{s}" height="{s}" fill="{NAVY}"/>'

SVGS = {
    # app icon / general use: rounded navy tile
    "icon.svg": svg(detailed(256, 256, 186, 12, "a"), bg=rounded_bg(512, 112)),
    # small-size favicon: rounded tile, simplified scale, bigger field
    "favicon.svg": svg(simple(256, 256, 204, 0, "s"), bg=rounded_bg(512, 112)),
    # logo without a tile (transparent), for headers etc.
    "logo.svg": svg(detailed(256, 256, 236, 14, "l"), bg=f'<circle cx="256" cy="256" r="254" fill="{NAVY}"/>'),
    # maskable: full-bleed, field inside the 80% safe zone (r <= 204.8 incl. ring)
    "icon-maskable.svg": svg(detailed(256, 256, 160, 10, "m"), bg=square_bg(512)),
    # apple touch: full-bleed (iOS rounds corners itself), slightly larger field
    "apple-touch-icon.svg": svg(detailed(256, 256, 186, 12, "p"), bg=square_bg(512)),
}

# single-colour silhouette (Safari pinned tab / monochrome uses)
mono_k = 1
SVGS["icon-mono.svg"] = svg(f'''
  <defs><mask id="mm">
    <rect width="512" height="512" fill="#000"/>
    <circle cx="256" cy="256" r="206" fill="#fff"/>
    <rect x="0" y="274" width="512" height="300" fill="#000"/>
    <circle cx="256" cy="256" r="206" fill="none" stroke="#fff" stroke-width="20"/>
  </mask></defs>
  <rect width="512" height="512" fill="#000" mask="url(#mm)"/>
  {''.join(f'<line x1="200" y1="{y}" x2="{200 + (76 if i % 5 == 0 else 38)}" y2="{y}" stroke="#000" stroke-width="{9 if i % 5 == 0 else 6}"/>' for i, y in enumerate(range(118, 400, 18)))}
  <line x1="200" y1="114" x2="200" y2="398" stroke="#000" stroke-width="9"/>
''')

for name, s in SVGS.items():
    with open(os.path.join(OUT, name), "w") as f:
        f.write(s)

PNGS = [
    ("icon.svg", "icon-192.png", 192),
    ("icon.svg", "icon-512.png", 512),
    ("icon-maskable.svg", "icon-maskable-192.png", 192),
    ("icon-maskable.svg", "icon-maskable-512.png", 512),
    ("apple-touch-icon.svg", "apple-touch-icon.png", 180),
    ("favicon.svg", "favicon-16.png", 16),
    ("favicon.svg", "favicon-32.png", 32),
    ("favicon.svg", "favicon-48.png", 48),
    ("logo.svg", "logo-1024.png", 1024),
]


def render(page, svg_text, size):
    page.set_viewport_size({"width": size, "height": size})
    page.set_content(f'<html><body style="margin:0;background:transparent">'
                     f'{svg_text.replace("width=\"512\" height=\"512\"", f"width=\"{size}\" height=\"{size}\"", 1)}'
                     f'</body></html>')
    return page.screenshot(omit_background=True, clip={"x": 0, "y": 0, "width": size, "height": size})


with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page(device_scale_factor=1)
    for src, dst, size in PNGS:
        png = render(page, SVGS[src], size)
        img = Image.open(io.BytesIO(png)).convert("RGBA")
        if dst == "apple-touch-icon.png":
            img = img.convert("RGB")  # iOS wants opaque
        img.save(os.path.join(OUT, dst), optimize=True)
    b.close()

# favicon.ico (16/32/48)
icons = [Image.open(os.path.join(OUT, f"favicon-{s}.png")) for s in (16, 32, 48)]
icons[2].save(os.path.join(OUT, "favicon.ico"), sizes=[(16, 16), (32, 32), (48, 48)], append_images=icons[:2])

manifest = {
    "name": "Beer OG Calculator",
    "short_name": "OG Calc",
    "start_url": "/",
    "display": "standalone",
    "background_color": NAVY,
    "theme_color": NAVY,
    "icons": [
        {"src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
        {"src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
        {"src": "/icons/icon-maskable-192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable"},
        {"src": "/icons/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
        {"src": "/icons/icon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any"},
    ],
}
with open(os.path.join(OUT, "manifest.webmanifest"), "w") as f:
    json.dump(manifest, f, indent=2)

README = f"""# Beer OG Calculator — icon pack

Refractometer eyepiece view: blue above the reading line, white below, scale ticks that flip colour across the line.

Colours: navy {NAVY} (also theme_color), blue {BLUE_TOP} → {BLUE_LOW}, white {WHITE}, scale blue {TICK_ON_WHITE}.

## Files

| File | Use |
|---|---|
| favicon.ico | Legacy favicon (16, 32, 48) |
| favicon.svg | Modern favicon, simplified scale for tiny sizes |
| favicon-16/32/48.png | PNG favicons |
| apple-touch-icon.png | iOS home screen (180, opaque; iOS rounds the corners) |
| icon-192.png, icon-512.png | PWA icons, purpose "any" (rounded tile) |
| icon-maskable-192/512.png | PWA icons, purpose "maskable" (full bleed, content in safe zone) |
| icon.svg | Master app icon, vector |
| icon-maskable.svg, apple-touch-icon.svg | Vector sources for those PNGs |
| logo.svg, logo-1024.png | Round logo for headers, splash, docs |
| icon-mono.svg | One-colour silhouette (Safari pinned tab, print, embossing) |
| manifest.webmanifest | Ready-made manifest, icons expected under /icons/ |

## HTML head

```html
<link rel="icon" href="/icons/favicon.ico" sizes="48x48">
<link rel="icon" href="/icons/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
<link rel="mask-icon" href="/icons/icon-mono.svg" color="{NAVY}">
<link rel="manifest" href="/manifest.webmanifest">
<meta name="theme-color" content="{NAVY}">
```

Regenerate with `python3 build.py` (needs Playwright + Chromium and Pillow).
"""
with open(os.path.join(OUT, "README.md"), "w") as f:
    f.write(README)

# copy build script into the pack so it can be regenerated
import shutil
shutil.copy(__file__, os.path.join(OUT, "build.py"))
print("done", sorted(os.listdir(OUT)))
